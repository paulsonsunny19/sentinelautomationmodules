"""STAT Next enrichment modules."""
